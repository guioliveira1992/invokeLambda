exports.handler = async (event) => {
    console.log(event)
    let body = JSON.parse(event.body)
    const message = body.message;
    const response = {
        statusCode: 200,
        body: "This is a message sended by lambda, input: " + message,
    };
    return response;
};
